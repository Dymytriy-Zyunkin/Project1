/**
 * This is the driver class. It creates an instance of the Shopping class and runs it.
 * @author Dymytriy Zyunkin, Shuwei Cao
 */

public class RunProject1 {
	public static void main(String[] args) {
		System.out.println("Let's start shopping!");
		new Shopping().run();
	} 
}